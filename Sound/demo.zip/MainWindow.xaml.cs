﻿using soundtouch;
using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace demo
{
    public partial class MainWindow : Window
    {
        protected SoundProcessor processor = new SoundProcessor();
        NAudioRecorder recorder;
        public bool isRecording = false;
        public MainWindow()
        {
            InitializeComponent();

            StatusMessage.statusEvent += StatusEventHandler;
            processor.PlaybackStopped += EventHandler_playbackStopped;
            DisplaySoundTouchVersion();
        }

        private void DisplaySoundTouchVersion()
        {
            string status;
            try
            {
                status = String.Format("SoundTouch version: {0}", SoundTouch.GetVersionString());
            }
            catch (Exception exp)
            {
                status = exp.Message;
            }
            text_status.Text = status;
        }


        private void StatusEventHandler(object sender, string msg)
        {
            text_status.Text = msg;
        }


        private void button_browse_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog openDialog = new Microsoft.Win32.OpenFileDialog();
            openDialog.Filter = "Wav files (*.wav)|*.wav|MP3 files (*.mp3)|*.mp3";
            if (openDialog.ShowDialog() == true)
            {
                if (processor.OpenMp3File(openDialog.FileName) == true)
                {
                    textBox_filename.Text = openDialog.FileName;
                    button_play.IsEnabled = true;
                    button_stop.IsEnabled = true;

                    ParseTempoTextBox();
                    ParsePitchTextBox();
                    ParseRateTextBox();
                }
                else
                {
                    MessageBox.Show("找不到 " + openDialog.FileName);
                }
            }
        }


        private void setPlayButtonMode(bool play)
        {
            button_play.Content = play ? "播放" : "暂停";
        }


        private void EventHandler_playbackStopped(object sender, bool hasReachedEnd)
        {
            if (hasReachedEnd)
            {
                text_status.Text = "停止";
            }

            setPlayButtonMode(true);
        }


        private void button_play_Click(object sender, RoutedEventArgs e)
        {
            if (button_play.Content.ToString() == "暂停")
            {
                if (processor.Pause())
                {
                    text_status.Text = "暂停";
                }
                setPlayButtonMode(true);
            }
            else
            {
                if (processor.Play())
                {
                    text_status.Text = "继续";
                    setPlayButtonMode(false);
                }
            }
        }


        private void button_stop_Click(object sender, RoutedEventArgs e)
        {
            if (processor.Stop())
            {
                text_status.Text = "停止";
            }
            setPlayButtonMode(true);
        }


        private bool parse_percentValue(TextBox box, out double value)
        {
            if (double.TryParse(box.Text, out value) == false) return false;
            if (value < -99.0) value = -99.0;   // don't allow more than -100% slowdown ... :)
            box.Text = value.ToString();
            return true;
        }


        private void ParsePitchTextBox()
        {
            double pitchValue;
            if (double.TryParse(textBox_pitch.Text, out pitchValue))
            {
                if (processor.streamProcessor != null) processor.streamProcessor.st.SetPitchSemiTones((float)pitchValue);
            }
        }


        private void ParseTempoTextBox()
        {
            double tempoValue;
            if (parse_percentValue(textBox_tempo, out tempoValue))
            {
                if (processor.streamProcessor != null) processor.streamProcessor.st.SetTempoChange((float)tempoValue);
            }
        }


        private void ParseRateTextBox()
        {
            double rateValue;
            if (parse_percentValue(textBox_rate, out rateValue))
            {
                if (processor.streamProcessor != null) processor.streamProcessor.st.SetRateChange((float)rateValue);
            }
        }


        private void textBox_tempo_LostFocus(object sender, RoutedEventArgs e)
        {
            ParseTempoTextBox();
        }


        private void textBox_tempo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // enter pressed -- parse value
                ParseTempoTextBox();
            }
        }


        private void textBox_pitch_LostFocus(object sender, RoutedEventArgs e)
        {
            ParsePitchTextBox();
        }


        private void textBox_pitch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // enter pressed -- parse value
                ParsePitchTextBox();
            }
        }


        private void textBox_rate_LostFocus(object sender, RoutedEventArgs e)
        {
            ParseRateTextBox();
        }


        private void textBox_rate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // enter pressed -- parse value
                ParseRateTextBox();
            }
        }

        private void btnRecording_Click(object sender, RoutedEventArgs e)
        {
            
            var outputFolder = Path.Combine(Environment.CurrentDirectory, "NAudio");
            var outputFilePath = Path.Combine(outputFolder, "recorded.wav");

            if (!isRecording)
            {
                isRecording = true;
                btnRecording.Content = "停止录音";
                recorder = new NAudioRecorder();
                //开始录音
                recorder.SetFileName(outputFolder);
                recorder.StartRec();

            }
            else {
                isRecording = false;
                btnRecording.Content = "录音";
                recorder.StopRec();
                //
            }

        }
    }
}
