﻿using System.Windows;

namespace demo
{
    public partial class App : Application
    {
    }
}
